clc; clear; close all;
% load image
f_img = im2double(imread('.\images\face.jpg'));
t_img = im2double(imread('.\images\toast.jpg'));
[fh,fw,~] = size(f_img);
[th,tw,~] = size(t_img);
    figure(1),
    subplot(121),imshow(t_img),title('The original texture image');
    subplot(122),imshow(f_img),title('The original target image');
    print(1,'-djpeg','.\results\ft_ori_img.jpg');

% texture transfer
patchsize = 35;
overlap = floor(patchsize / 5);
tol = 0.1;
iter_num = 3;
off_h = round((th-fh)/2); off_w = round((tw-fw)/2);
toast = t_img( off_h : off_h+fh , off_w : off_w+fw, :);
% imshow(toast);
face_tr = iter_tex_transfer(toast,f_img, patchsize,overlap,tol,iter_num);
figure(2),imshow(face_tr),title('transfered face imge');

% Feathering and blending
fmask = ones(fh,fw);
mask = zeros(th,tw);
mask(off_h+1: off_h+fh, off_w+1: off_w+fw) =fmask;
fil = fspecial('gaussian',7*15,15);
mask = imfilter(mask,fil);
figure(3),imshow(mask),title('Feather mask');
face = ones(th,tw,3);
face(off_h+1: off_h+size(face_tr,1), off_w+1: off_w+size(face_tr,2),:) = face_tr;

face_on_toast = face.*mask + t_img.*(1-mask);
figure(4),imshow(face_on_toast),title('The face on toast result');