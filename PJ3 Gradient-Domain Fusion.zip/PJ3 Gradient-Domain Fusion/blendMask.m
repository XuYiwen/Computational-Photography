function out_mask = blendMask(in_mask,width)
[imh,imw] = 