function mix = mixedValue(graf,grab)
if abs(graf)>= abs(grab)
    mix = graf;
else
    mix = grab;
end

